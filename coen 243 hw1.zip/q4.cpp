#include <iostream>
using namespace std;

int main()

{
	cout<<"Question 4:\n";
	int number ; // setting the type of the number chosen as an integer
	cout<<"Enter a positive integer:\n"; // print the text
	cin>>number; // will allow user to pick an integer
	if (number%5==0) // a if statement being used for a condition
		cout<< number <<" is a multiple of 5"; // if the remainder of your number divided by 5 is 0 then will print out this statement
	else
		cout<< number << " is not a multiple of 5"; // if the remainder is not 0 then it will print out this statement
	return 0; // program is successfully ended

} // funtion is done





