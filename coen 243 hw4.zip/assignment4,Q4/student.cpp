#include "student.h"
#include <iostream>
#include<string>
using namespace std;
string student::getfirst() // return first if write student::getfirst()
{
	return first;
}

string student::getlast() // return last if write student::getlast()
{
	return last;
}

int student::age() // return age if write student::age()
{
	return Age;
}

int student::areacode() // return area if write student::areacode()
{
	return area;
}

string student::address() // return Address if write student::address()
{
	return Address;
}
string student::getfull() // return fullname if write student::getfull()
{
	return fullname;
}

string student::telephone() // return tel if write student::telephone()
{
	return tel;
}

int student::getID() // return ID if write student::getID()
{
	return ID;
}

void student::dateofbirth() // return date/month/year format if write student::dateofbirth()
{
	std::cout<<date<<"/"<<month<<"/"<<year;
}
student::student(int I,string f,string l,int a,string add,string t,int day,int m,int y )
{// re-assigning the variable
	ID=I;
	first=f;
	last=l;
	area=a;
	Address=add;
	tel=t;
	year=y;
	Age=2017-year;
	fullname=f+ " "+l;
	date=day;
	month=m;
}
