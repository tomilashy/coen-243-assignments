#include <iostream>
using namespace std;

int main()

{
	cout<<"Question 1:\n";
	int number; // giving a type to number
	cout<<"Enter a integer:\n"; // print out the text
	cin>> number; // let the user pick an integer
	cout<< number<< number<< number<< number << number<< number<< number<< number<< number<<number<<number<<"\n"; // print out 11 times the number
	cout<<number<< number<< number<<"\t"<<"\t"<<"\t"<<number<<number<<"\t"<<"\t"<<number<<number<<"\n"; //print out the 3 times the number and create separation with tab and continue printing the number
	cout<<number<< number<< number<<"\t"<<"\t"<<"\t"<<number<<number<<"\t"<<"\t"<<number<<number<<"\n"; // print the number and create separation
	cout<<number<< number<< number<<"\t"<<"\t"<<"    "<< number<<number<< number<< number<< number<< number << number<< number<< number<< number<< number<<"     "<<number<<number<< number<< number<< number<< number << number<< number<< number<< number<< number<<"\n";// print the number and create separation
	cout<<number<< number<< number<<"\t"<<"\t"<<"\t"<<number<<number<<"\t"<<"\t"<<number<<number<<"\n";// print the number and create separation
	cout<<number<< number<< number<<"\t"<<"\t"<<"\t"<<number<<number<<"\t"<<"\t"<<number<<number<<"\n";// print the number and create separation
	cout<< number<< number<< number<< number << number<< number<< number<< number<< number<<number<<number<<"\n";// print the number and create separation

	return 0; // program done successfully
} // program done
