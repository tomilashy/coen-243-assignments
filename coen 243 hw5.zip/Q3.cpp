#include <iostream>
#include<array>
using namespace std;

int main()
{
//	a.
	const int size=10;
	unsigned int array[size];

	cout<<"Enter 10 values \n";

	for(int q=0; q<size;q++)
	{
		cout<<"Enter value for "<<q+1;
		cin>>array[q];
	}
	cout<<"\n";
//	b.
	for(int p=0; p<size;p++)
	{
		cout<<"The value for "<<p+1<<"=";
		cout<<array[p]<<endl;
	}
		cout<<endl;
//	c.
	unsigned int* xptr;
//	d..
	xptr=&array[0];

//	e.
	for(int p=0; p<size;p++)
	{
		cout<<"The value for "<<p+1<<"=";
		cout<<*(xptr+p)<<endl;
		cout<<"Address "<<p+1<<"=";
		cout<<xptr+p<<"\n";
	}
	cout<<"\n";
//f.
	cout<<"Address:";
	cout<<array<<"\n";

//g.
	unsigned int* zPtr;
//h.
	zPtr= new unsigned int[size];
//i.
	for(int q=0;q<size;q++)
	{
		zPtr[q] = array[q];
	}

//j.
	for(int p=0; p<size;p++)
	{
		cout<<"Value of new array for "<<p+1<<"=";
		cout<<zPtr[p]<<endl;
		cout<<"New address "<<p+1<<"=";
		cout<<&zPtr[p]<<"\n";
	}

//k.

	delete[] zPtr;
	return 0;
}




