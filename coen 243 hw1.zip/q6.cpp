#include <iostream>
using namespace std;

int main()
{
	cout<<"Question 6:\n";
	double pi=0 ; // pi is set to be any number
	long i; // allows i to have many digit after the decimal
	long n; // allows n to have many digit after the decimal
	cout << "Enter the value of n: "; // Enter a value for n
	cout << endl;
	cin >> n; // input a number n
	for (i = 0; i < n; i++) // i equal n
	{if (i % 2 == 0) // an if statement that the remainder of i/2 equal to 0 then print the next line
		 pi = pi + (1.0 / (2 * i + 1));
	else { // an else statement for if the if statement is incorrect
		 pi = pi - (1.0 / (2 * i + 1));
	} }

		pi = 4 * pi; // pi is equal to pi*4


	cout<< endl << "pi = " << pi << endl; // will print pi= to the value of pi

	return 0; // program successfully executed
} // program is done





