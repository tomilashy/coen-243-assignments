#include "student.h"
#include <iostream>
#include<array>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
	int I,a,day,m,y; //initializing
	string f,l,add,t; //initializing

	int Id1,area1,day1,month1,year1; //initializing
	string first1,last1,Address1,tel1; //initializing


		cout<<"student's address";
		getline(cin,add); // input address
		cout<<"student's area code";
		cin>>a; // input area code
		cout<<"student's telephone number";
		cin>>t; //input telephone
		cout<<"student's first name";
		cin>>f; // input first name
		cout<<"student's last name";
		cin>> l; // input last name
		cout<<"student's date of birth ";
		cin>>day; // input birth day
		cout<<"student's birth-month";
		cin>>m; // input birth month
		cout<<"input the student's birth-year";
		cin>>y; // input birth year
		cout<<"student's ID number";
		cin>>I;cout<<"\n"; //input id
		student stud(I,f, l, a, add,t,day,m, y);


		cout<<"student's address";
		cin.ignore(256,'\n');
		getline(cin,Address1); // input address
		cout<<"student's area code";
		cin>>area1;// input area code
		cout<<"student's telephone number";
		cin>>tel1; //input telephone
		cout<<"student's first name";
		cin>>first1; // input first name
		cout<<"student's last name";
		cin>> last1; //input last name
		cout<<"student's date of birth";
		cin>>day1; //input birth day
		cout<<"student's birth-month";
		cin>>month1; //input birth month
		cout<<"student's birth-year";
		cin>>year1; //input birth year
		cout<<"student's ID number";
		cin>>Id1;cout<<"\n"; //input id
		student Stud(Id1,first1, last1, area1, Address1,tel1, day,month1,year1);

		cout<<"The info that where enter for student "<<1<<endl;// will print out all the input inputed for each student
		cout<<"full name: "<<stud.getfull()<<endl
			<<"Date of birth: ";stud.dateofbirth();
		cout<<endl
			<<"Age: "<<stud.age()<<endl;
		cout<<"student ID: "<<stud.getID()<<endl;
		cout<<"Area code: "<<stud.areacode()<<"\n";
		cout<<"Phone number: "<<stud.telephone()<<"\n";
		cout<<"Address: "<<stud.address()<<"\n\n";

		cout<<"Below are the details for student "<<2<<endl;
		cout<<"full name: "<<Stud.getfull()<<endl
			<<"Date of birth: ";Stud.dateofbirth();
			cout<<endl
			<<"Age: "<<Stud.age()<<endl;
		cout<<"student ID: "<<Stud.getID()<<endl;
		cout<<"Area code: "<<Stud.areacode()<<endl;
		cout<<"Phone number: "<<Stud.telephone()<<"\n";
		cout<<"Address: "<<Stud.address()<<endl;

		if (stud.address()==Stud.address()) // if address is identical
{
			cout<<"They are roommates\n";

}
		if (stud.getlast()==Stud.getlast()) //if last name are identical print next line
{
					cout<<
						"same last name";
}

	return 0;
}
