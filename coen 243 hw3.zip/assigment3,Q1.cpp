#include <iostream>
#include <string>
using namespace std;
void regular(int,int,int,int);
void personal(int,int,int,int);
void bootcamp(int,int,int,int);
void customer();
void headoffice();
int main()
{
cout<<"Do you want access the customer file or the head office? Enter 0 for customer or 1 for the head office.\n ";
int option;
cin>>option;
if (option==0) // will use the function customer
{
	customer();
}
else if (option==1)
{
headoffice(); // will use the function headoffice
}
return 0;
}

void headoffice()
{
int password;
cout<<"Enter the 4 digit password:";
cin>>password;
if(password==1234) // if password is correct will print next line and will let the head office change the rate and will display new rates for each case
{
cout<<"Enter the new value for regular: \n";
int r;
cin>>r;
cout<<"Enter the new value for personal: \n";
int p;
cin>>p;
cout<<"Enter the new value for bootcamp: \n";
int b;
cin>>b;

cout<<"The new value for regular: "<<r<<"$ per month\n";
cout<<"The value for regular, senior, not student and no advance payment: "<<r-(r*0.30)<<"$\n";
cout<<"The value for regular, not senior, not student and no advance payment: "<<r<<"$\n";
cout<<"The value for regular, not senior, student and no advance payment: "<<r-(r*0.25)<<"$\n";
cout<<"The value for regular, not senior, student and advance payment: "<<r-(r*0.35)<<"$\n";
cout<<"The value for regular, senior, not student and advance payment: "<<r-(r*0.40)<<"$\n";
cout<<"The value for regular, not senior, not student and advance payment: "<<r-(r*0.10)<<"$\n";
cout<<"The value for regular, senior,  student and  advance payment: "<<r-(r*0.65)<<"$\n";
cout<<"The value for regular, senior,  student and no advance payment: "<<r-(r*0.55)<<"$\n";

cout<<"The new value for personal: "<<p<<"$ per sessions\n";
cout<<"The value for regular+ 1 personal, senior, not student and no advance payment: "<<(p+r)-(p+r)*0.30<<"$\n";
cout<<"The value for regular+ 1 personal, not senior, not student and no advance payment: "<<p+r<<"$\n";
cout<<"The value for regular+ 1 personal, not senior, student and no advance payment: "<<(p+r)-((p+r)*0.25)<<"$\n";
cout<<"The value for regular+ 1 personal, not senior, student and advance payment: "<<(p+r)-((p+r)*0.35)<<"$\n";
cout<<"The value for regular+ 1 personal, senior, not student and advance payment: "<<(p+r)-((r+p)*0.40)<<"$\n";
cout<<"The value for regular+ 1 personal, not senior, not student and advance payment: "<<(p+r)-((r+p)*0.10)<<"$\n";
cout<<"The value for regular+ 1 personal, senior,  student and  advance payment: "<<(p+r)-((p+r)*0.65)<<"$\n";
cout<<"The value for regular+ 1personal, senior,  student and no advance payment: "<<(p+r)-((p+r)*0.55)<<"$\n";

cout<<"The new value for bootcamp: "<<b<<"$ per sessions\n";
cout<<"The value for regular+ 1 bootcamp, senior, not student and no advance payment: "<<(b+r)-(b+r)*0.30<<"$\n";
cout<<"The value for regular+ 1 bootcamp, not senior, not student and no advance payment: "<<b+r<<"$\n";
cout<<"The value for regular+ 1 bootcamp, not senior, student and no advance payment: "<<(b+r)-((b+r)*0.25)<<"$\n";
cout<<"The value for regular+ 1 bootcamp, not senior, student and advance payment: "<<(b+r)-((b+r)*0.35)<<"$\n";
cout<<"The value for regular+ 1 bootcamp, senior, not student and advance payment: "<<(b+r)-((b+r)*0.40)<<"$\n";
cout<<"The value for regular+ 1 bootcamp, not senior, not student and advance payment: "<<(b+r)-((r+b)*0.10)<<"$\n";
cout<<"The value for regular+ 1 bootcamp, senior,  student and  advance payment: "<<(b+r)-((b+r)*0.65)<<"$\n";
cout<<"The value for regular+ 1 bootcamp, senior,  student and no advance payment: "<<(b+r)-((b+r)*0.55)<<"$\n";

}
else if(password!=1234) // if password is incorrect
{
	cout<<"Access denied!!!\n";
}
}

void customer() // will ask all information of the customer
{
	cout << "Which membership would you like: regular=22$, regular+ 1 session personal=56$ or 1 session bootcamp+ regular=147$ \n";
				int q;
				cin >> q;
				cout<<"Are you aged above 65? Enter 0 for yes and 1 for no \n";
				int y;
				cin>>y;
				cout<<"Are you a student? Enter 0 for yes and 1 for no.\n";
				int x;
				cin>>x;
				cout<<"Will you pay 12 month in advance: 0 for yes or 1 for no \n ";
				int a;
				cin>>a;
				if (q==22) // if the customer chose 22$ will use the regular function
				{
				regular(q,y,x,a);
				}
				else if(q==56) // if the customer chose 56$ will use the personal function
				{
				personal(q,y,x,a);
				}
				else if(q==147) // if the customer chose 147$ will use the bootcamp function
				{
				bootcamp(q,y,x,a);
				}
}

void regular(int q,int y,int x, int a) // regular function with all the possible possibility
{
			if (q==22 && y==0 && x==1 && a==1 )
				{
				cout<<"The prices per month: "<<q-(q*0.30)<<"$";
				}
			else if (q==22 && y==1 && x==1 && a==1)
			{
				cout<<"The prices per month: "<<q<<"$";
			}
			else if (q==22 && y==1 && x==0 && a==1)
			{
				cout<<"The prices per month: "<<q-(q*0.25)<<"$";
			}
			else if (q==22 && y==1 && x==0 && a==0)
			{
				cout<<"The prices per month: "<<q-(q*0.35)<<"$";
			}
			else if (q==22 && y==0 && x==1 && a==0)
			{
				cout<<"The prices per month: "<<q-(q*0.4)<<"$";
			}
			else if (q==22 && y==1 && x==1 && a==0)
			{
				cout<<"The prices per month: "<<q-(q*0.10)<<"$";
			}
			else if (q==22 && y==0 && x==0 && a==0)
			{
				cout<<"The prices per month: "<<q-(q*0.65)<<"$";
			}
			else if (q==22 && y==0 && x==0 && a==1)
			{
				cout<<"The prices per month: "<<q-(q*0.55)<<"$";
			}


}

void personal(int q,int y,int x, int a) // personal function with all the possible possibility
{
			if (q==56 && y==0 && x==1 && a==1 )
			{
				cout<<"The prices for a regular member plus 1 personal sessions(for more session additional charge of 34$/sessions): "<<q-(q*0.30)<<"$";
			}
			else if (q==56 && y==1 && x==1 && a==1)
			{
				cout<<"The prices for a regular member plus 1 personal sessions(for more session additional charge of 34$/sessions): "<<q<<"$";
			}
			else if (q==56 && y==1 && x==0 && a==1)
			{
				cout<<"The prices for a regular member plus 1 personal sessions(for more session additional charge of 34$/sessions): "<<q-(q*0.25)<<"$";
			}
			else if (q==56 && y==1 && x==0 && a==0)
			{
				cout<<"The prices for a regular member plus 1 personal sessions(for more session additional charge of 34$/sessions): "<<q-(q*0.35)<<"$";
			}
			else if (q==56 && y==0 && x==1 && a==0)
			{
				cout<<"The prices for a regular member plus 1 personal sessions(for more session additional charge of 34$/sessions): "<<q-(q*0.4)<<"$";
			}
			else if (q==56 && y==1 && x==1 && a==0)
			{
				cout<<"The prices for a regular member plus 1 personal sessions(for more session additional charge of 34$/sessions): "<<q-(q*0.10)<<"$";
			}
			else if (q==56 && y==0 && x==0 && a==0)
			{
				cout<<"The prices for a regular member plus 1 personal sessions(for more session additional charge of 34$/sessions): "<<q-(q*0.65)<<"$";
			}
			else if (q==56 && y==0 && x==0 && a==1)
			{
				cout<<"The prices for a regular member plus 1 personal sessions(for more session additional charge of 34$/sessions): "<<q-(q*0.55)<<"$";
			}


}

void bootcamp(int q,int y,int x, int a) // bootcamp function that displays all the possible possibility
{
			if (q==147 && y==0 && x==1 && a==1 )
			{
				cout<<"The prices for a regular member plus 1 bootcamp sessions(for more session additional charge of 125$/sessions): "<<q-(q*0.30)<<"$";
			}
			else if (q==147 && y==1 && x==1 && a==1)
			{
				cout<<"The prices for a regular member plus 1 bootcamp sessions(for more session additional charge of 125$/sessions): "<<q<<"$";
			}
			else if (q==147 && y==1 && x==0 && a==1)
			{
				cout<<"The prices for a regular member plus 1 bootcamp sessions(for more session additional charge of 125$/sessions): "<<q-(q*0.25)<<"$";
			}
			else if (q==147 && y==1 && x==0 && a==0)
			{
				cout<<"The prices for a regular member plus 1 bootcamp sessions(for more session additional charge of 125$/sessions): "<<q-(q*0.35)<<"$";
			}
			else if (q==147 && y==0 && x==1 && a==0)
			{
				cout<<"The prices for a regular member plus 1 bootcamp sessions(for more session additional charge of 125$/sessions): "<<q-(q*0.4)<<"$";
			}
			else if (q==147 && y==1 && x==1 && a==0)
			{
				cout<<"The prices for a regular member plus 1 bootcamp sessions(for more session additional charge of 125$/sessions): "<<q-(q*0.10)<<"$";
			}
			else if (q==147 && y==0 && x==0 && a==0)
			{
				cout<<"The prices for a regular member plus 1 bootcamp sessions(for more session additional charge of 125$/sessions): "<<q-(q*0.65)<<"$";
			}
			else if (q==147 && y==0 && x==0 && a==1)
			{
				cout<<"The prices for a regular member plus 1 bootcamp sessions(for more session additional charge of 125$/sessions): "<<q-(q*0.55)<<"$";
			}

}
