#include <iostream>
#include <string>
using namespace std;

int main() {
	int w,v,x,A1,A2; //Initializing all these value to integers
	cout<<"Input the number of apartment the company owns: ";
	cin>>v;
	cout<<"Input the monthly rent paid?";
	cin>>w;
	cout <<"Input the increase in rent ";
	cin>>x;
	cout<<"Input the maintenance fee per month for a rented apartment?";
	cin>>A2;
	cout<<"Input the maintenance fee per month for a vacant apartment?";
	cin>>A1;

	int q;// initializing these variable to integers
	int profit;// initializing these variable to integers
	int m;// initializing these variable to integers
	int p; // initializing these variable to integers
	for (q=0; q<=v; q++) // for loop where q start at zero and keeps on increasing until q is smaller or equal to v
	{
		profit = (q*w)+((v-q)*x)-((v-q)*A1)-(q*A2); // equation for the profit

		if (m < profit )
		{
			m = profit;

			if (m >= profit )
			{
				p=q;
			}

		}
	}
	cout <<"The profit is "<<m<<" $ if you rent out "<<p<<" and leave "<<v-p<<" vacant";
	return 0;
}





