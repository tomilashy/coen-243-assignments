#include <iostream>
using namespace std;

int gcd(int x, int y) {
	while(x != y) { // x not equal to y
		if (x>y) // if x bigger then y then print next line
			x-=y; // x is equal to x-y
		else
			y-=x; // y is equal to y-x
	}
	return x; // give out the value of x
}

int main() {
	int a,b; // a and b are integer
	cout<<"Enter two positive integers: ";
	cin>>a;
	cin>>b;
	if (a<0) // if a is smaller then 0 give out next line, because we cant allow user to use negative numbers
		a=-a;
	if (b<0) // if b is smaller then 0 give out next line, because we cant allow user to use negative numbers
		b=-b;
	cout<<gcd(a,b)<<" is the gcd of "<< a <<" and "<<b;
}




