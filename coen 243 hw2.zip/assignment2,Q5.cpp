#include <iostream>
#include <string>
using namespace std;
int longhours();
int shorthours();
int LongFormat(int & Hour,int & Minute,int & Seconds);
int ShortFormat(int & Hour,int & Minute,int & Seconds);
int q, hour, minute, seconds;

int main()
{
	do {
		cout << "Pick which notation to convert to 12 or 24:\n";
		cin >> q;
		} while (q != 12 && q != 24);// q is not equal to 12 and not equal to 24

	if (q == 24) // if q is equal to 24 do next lines
	{
		cout<<longhours();
	}
	else if (q == 12) // if q is equal to 12 then print next lines
	{cout<<shorthours();
	}
}

int shorthours()
{
	{
		do {
					cout << "hour in 24-hour format\n";
					cin >> hour;
					cout << "minute in 24-hour format\n";
					cin >> minute;
					cout << "seconds in 24-hour format\n";
					cin >> seconds;

				} while ((hour > 23 || hour < 0) || (minute > 59 || minute < 0) || (seconds > 59 || seconds < 0));
			cout<<ShortFormat(hour, minute,seconds);
		}
	return 0;
	}

int longhours()
{
	do {
					cout << "hour in 12-hour format\n";
					cin >> hour;
					cout << "minute in 12-hour format\n";
					cin >> minute;
					cout << "seconds in 12-hour format\n";
					cin >> seconds;
				} while ((hour > 12 || hour < 0) || (minute > 59 || minute < 0) || (seconds > 59 || seconds < 0));
			cout<<LongFormat(hour,minute,seconds);
			return 0;
		}


int LongFormat(int & Hour,int & Minute,int & Seconds)
{
		string time;
		cout<< "input AM or PM \n";
		cin >> time;

		if (time == "AM") // time is equal to AM
		{
			if (Hour == 12) // if statement if Hour is equal to 12 then print next line
				cout << "time is 00" << ":" << Minute << ":" << Seconds;
			else // if previous statement wrong then print next line
				cout << "time is " << Hour << ":" << Minute << ":" << Seconds	;
		}

		else if (time == "PM") // if t is equal to PM then will follow the next lines
		{
			if (Hour == 12) // if Hour is equal to 12 then print next line
				cout << "time is " << Hour << ":" << Minute << ":" << Seconds	;
			else // if previous statement was false print next line
				cout << "time is " << Hour + 12 << ":" << Minute << ":" << Seconds;

	}
return 0;
}

int ShortFormat(int & Hour,int & Minute,int & Seconds) {

	if (Hour < 12 && Hour > 0) // if Hour is smaller then 12 and H bigger then 0 print next line
		cout << "time is " << Hour << ":" << Minute << ":" << Seconds << " AM"	;
	else if (Hour == 0) // nested if statement if H is equal to 0 then print next line
		cout << "time is " << Hour + 12 << ":" << Minute << ":" << Seconds;
	else if (Hour == 12)//if Hour is equal to 12 then print next line
		cout << "time is " << Hour << ":" << Minute << ":" << Seconds<< " PM"	;
	else if (Hour > 12) // if Hour greater then 12 then print next line
		cout << "time is " << Hour-12 << ":" << Minute << ":" << Seconds << " PM"	;
return 0;
}


