#include<iostream>
#include<string>
#include "passenger.h"
using namespace std;

int Passenger::getID1()
{
	return ID;
}
string Passenger::getfirstname1()
{
	return firstname;
}

string Passenger::getlastname1()
{
	return lastname;
}

string Passenger::getcompletename1()
{
	return completename;
}

string Passenger::tel1()
{
	return tel;
}

string Passenger::address1()
{
	return address;
}

void Passenger::dateofbirth1()
{
	cout<<day<<"/"<<month<<"/"<<year;
}
Passenger::Passenger(int I, string f, string l,string telephone, string add, int d, int m, int y)
{
	// re-assigning the variable
	ID=I;
	firstname=f;
	lastname=l;
	completename= f+ " "+ l;
	tel=telephone;
	address=add;
	day=d;
	month=m;
	year=y;

}
