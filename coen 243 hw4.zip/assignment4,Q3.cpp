#include <iostream>
#include <iomanip>
#include <unistd.h>
using namespace std;
// Time abstract data type (ADT) definition
class Time {
public:
Time(); // constructor
void setTime(int, int, int); // set hour, minute, second
void printUniversal(); // print universal-time format
void printStandard(); // print standard-time format
void tick()
{
	second += 1;
	if (second>=60)
	{
		minute+= 1;
		second =0;
	}

	if (minute>=60)
		{
			hour+= 1;
			minute =0;
		}
	if (hour>=24)
		{
			hour=0;
			minute=0;
			second=0;
		}
};


private:
int hour; // 0 - 23 (24-hour clock format)
int minute; // 0 - 59
int second; // 0 - 59
}; // end class Time



// ensures all Time objects start in a consistent state
Time::Time()
{
hour = 0;
minute = 0;
second = 0;
} // end Time constructor
// set new Time value using universal time, perform validity
// checks on the data values and set invalid values to zero
void Time::setTime(int h, int m, int s)
{
hour = (h >= 0 && h < 24) ? h : 0;
minute = (m >= 0 && m < 60) ? m : 0;
second = (s >= 0 && s < 60) ? s : 0;
}



void Time::printUniversal()
{
cout << setfill('0') << setw(2) << hour << ":"
<< setw(2) << minute << ":"
<< setw(2) << second;
} // end function printUniversal
// print Time in standard format
void Time::printStandard()
{
cout << ((hour == 0 || hour == 12) ? 12 : hour % 12)
<< ":" << setfill('0') << setw(2) << minute
<< ":" << setw(2) << second
<< (hour < 12 ? " AM" : " PM");
}

int main()
 {
	Time t;
	int x,y,z;
	cout<<"Enter the time.\n"
			"input the hour,minutes and seconds(give spaces between them)";
	cin>>x;

	cin>>y;

	cin>>z;

	t.setTime(x, y, z); // change time

	cout << "\n\nUniversal time after setTime is ";

	t.printUniversal(); // 13:27:06
	cout << "\nStandard time after setTime is ";
	t.printStandard(); // 1:27:06 PM
	while (1){
	t.tick();
	cout << "\n\nUniversal time after setTime is ";
	t.printUniversal();
	cout << "\nStandard time: ";
	t.printStandard(); // 12:00:00 AM
	cout << endl;
	sleep(1);
 }
return 0;
}



