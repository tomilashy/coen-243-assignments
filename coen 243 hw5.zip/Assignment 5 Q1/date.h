#ifndef DATE_H_
#define DATE_H_

class Date{

public:

	Date(int = 1, int = 1, int = 2000); //sets day, month, year
	void printDate() const; //print date to the screen
	void date(); //will give the date
	void monthinletters(); // will give the month in letter
	int daysbetweentwodate() //days between two date
	{
		if(month < 3)
			year--, month+= 12;
		return 365*year + year/4 -year/100 +year/400+ (153*month-475)/5+day-306;
	};

private:

	int day;
	int month;
	int year;

};



#endif /* DATE_H_ */

