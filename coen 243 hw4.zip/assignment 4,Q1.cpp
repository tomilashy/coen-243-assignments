#include <iostream>
#include <iomanip>
#include<array>
using namespace std;

int sumVotes(int x[]) // function for votes
{
	int y=0;
	for (int q=0;q<5;q++) // for loop
	{
		y += x[q]; // y= y+x[q] until q=4
	}
	return y;
}

void winnerIndex(int x[],string z[]) // function for winner
{
	int p=0;
	for (int q=0;q<5;q++) // for loop
	{
		if(x[q]>p)
		{
			p = x[q]; // for loop where p= p+x[q] until q=4
		}
	}
	for (int r=0;r<5;r++) // for loop
	{
		if (x[r]==p) // if true print out next line
		{
			cout<<"Winner:  "<<z[r];
		}
	}
}
int main() // main function
{
	string i[5];
	int votes[5];
	for (int q=0;q<5;q++) // for loop that will repeat itself until all information of all 5 candidate are entered
	{
		cout<<"Enter the name of candidate "<<q+1<<endl;
		cin>>i[q];
		cout<<"Enter the number of votes of candidate "<<q+1<<endl;
		cin>>votes[q];
	}

	int v=sumVotes(votes); // v represent the total votes

	cout<<setw(20)<<left<<"Candidates"<<setw(29)<<left<<"Votes Received"<<"% of Total Votes \n\n";
	for (int b=0;b<5;b++) // for loops that will repeat all the following step for each candidates
	{
		cout<<setw(20)<<left<<i[b]<<setw(29)<<left<<votes[b]<<(100*votes[b])/v<<endl;
	}
	cout<<setw(20)<<left<<"Total"<<v<<endl; // print out the total votes

	winnerIndex(votes,i); // will print out the winner
}





