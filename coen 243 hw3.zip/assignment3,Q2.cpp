#include <iostream>
#include<cmath>
using namespace std;
// no prototype needed because functions comes before the main function
int Double(int number) // function that will allows us to double a number
{
	return 2*number;
}

double sqroot(double number) // function that will allow us to root a number
{
	return sqrt(number/1.0);
}

void reverse(int x) // function that will give the reverse of a number
{
	int reversed = 0, remainder;
	while(x != 0)
	    {
	        remainder = x%10;
	        reversed = reversed*10 + remainder;
	        x /= 10;
	    }

	    cout<< reversed;
}

double power(double number,double number1) // a function that gives us the number to a certain power
{
	return pow((double)number,number1);
}

void SumOfDigits(int number) // function that will give us the sum of the  digits of the number
{
	int numbersum = 0;
	int y = 1;
	for (y = 1; y <= 4; ++y){
	numbersum = numbersum + number % 10;
	number = number / 10;
	}
	cout<<numbersum;
}

bool prime(int x) // function that will tell if its a prime number or not
{
     int p,count=0;
     if(x==1)
      return false;
	 if(x==2)
      return true;
     if(x%2==0)
      return false;
     for(p=1;p<=x;p++)
      if(x%p==0) count++;
      if(count==2)
       return true;
      else
       return false;
}

int main()
{
	int number, number1;
	do{
	cout << "1. double the number\n""2. square root of a number\n""3. reverse the number\n""4. raise the number to a certain power.\n""5. sum the digits of the number\n""6. check if a number is a prime number\n";
	cin>>number;
	}while(number<1 || number>6);
	switch(number) // depending on the number the user will pick it will then use the case with the chosen number
	{
	case 1: // this case will be for doubling the number
		int number1;
		cout<<"Enter the number to be doubled: ";
		cin>> number1;
		cout<<Double(number1);
	break; // will stop the program
	case 2: // this case will be for rooting the number
		double number2;
		cout<<"Enter the value to be rooted: ";
		cin>> number2;
		cout<<sqroot(number2);
	break; // will stop the program
	case 3:// case will be reversing the value
		int number3;
		cout<<"Enter the value to be reversed: ";
		cin>> number3;
		reverse(number3);
	break; // will stop the program
	case 4:// case will be for calculation a number to a certain value
		double number4,exponent1;
		cout<<"Enter the value than you want to use as the base: ";
		cin>> number4;
		cout<<"Enter the value of the exponent: ";
		cin>>exponent1;
		cout<<power(number4,exponent1);
	break; // will stop the program
	case 5: // this case will add up the digits
		int number5;
		cout<<"Enter the value that will get its number added: ";
		cin>> number5;
		SumOfDigits(number5);
	break;// will stop the program
	case 6: // will let one know if the number is prime or not
		int number6;
		cout<<"Enter the value you that you want to verify if its a primer number: "
				"\n 1 will signify it is and 0 that it is not";
		cin>>number6;
		cout<<prime(number6);
	break;// will stop the program
	}
	return 0; // the function has been successfully completed
}
