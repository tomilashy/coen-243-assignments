#ifndef ROMAN_H_
#define ROMAN_H_
using namespace std;
class number
{
private:
        string Number1;
        int sum;
public:
    number( string input);
	number();

  int convert();

};

#endif /* ROMAN_H_ */
