#include <iostream>
using namespace std;

int main()

{
	cout<<"Question 2\n"; // print out the question
	cout<<"*****************************************\n"; // print out the stars
	cout<<"Input two different integers:"<<"\n"; // print out the text
	int number1; // setting type of number1 as an integer
	int number2; // setting the type of number2 as an integer
	cin>> number1; // will make it so that the user inputs the first number
	cin>> number2; //will make it so that the user inputs the first number
	cout<<"*****************************************\n"; // print out the stars
	cout<<"The results are: "<<"\n"; // will print the text

	cout<<"Sum is:          "        <<number1+number2<<"\n"; // will print the sum of number1 and number2
	cout<<"Average is:      "     <<(number1+number2)/2<<"\n"; // will calculate the average of number1 and number2
	cout<<"Product is:      "    <<number1*number2<<"\n"; // will calculate the product of number1 and number2
	cout<<"Difference is:   "  <<number1-number2<<"\n"; // will calculate the difference between number1 and number2
	cout<<"*****************************************"; // will print the stars

	return 0; //program is successfully done
} // function is done

