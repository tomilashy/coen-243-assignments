#include <iostream>
#include <string>
#include "roman.h"

using namespace std;

int main()
{
       string input; // input is set as a string
       int y = 0;
       int x;
       while(y ==0 ){
       cout<<"Enter the roman value in capital letter : ";
       cin>>input;
       cout<<"Which option: "
    		   "\n1. Convert to decimal numbers"
    		   "\n2. Give in Roman form"
    		   "\n3. Exit";
       cin>>x;
       if (x==1) // if x is equal to one will convert to decimal
       {
       number mynumber(input);

       int v = mynumber.convert();

       cout <<" Decimal form : " << v <<endl;
       }
       if (x==2) // if x is equal to 2, will give back roman number
             {
    	   cout << "Roman Number: " << input <<endl;

       }
       if (x==3) // if x is equal to 3 will exit the program
             {
    	   cout<<"Bye"<<endl;
    	   y = 1;

       }
}
       return 0;
}






