#include <iostream>
#include<array>
#include <iomanip>
#include <string>
#include "passenger.h"
using namespace std;

int main()
{
	int I,d,m,y,area; //initializing
	string f,l,add,telephone; //initializing
	int numberofpassenger=2; // setting the number of passenger info to 2
	Passenger* p= new Passenger[numberofpassenger];
		for (int q=0;q<numberofpassenger;q++) // to repeat twice for two passenger
		{
		cout<<"Passenger information: "<<q+1<< "\n";
		cout<<"ID number";
		cin>>I; // enter id
		cout<<"first name";
		cin>>f; // enter first name
		cout<<"last name";
		cin>> l; //enter last name
		cout<<"area code";
		cin>>area; //enter area code
		cout<<"telephone number";
		cin>>telephone; //enter the telephone number
		cout<<"address";
		cin.ignore(256,'\n');
		getline(cin,add); //enter the address
		cout<<"birth-day";
		cin>>d; //enter the birthday
		cout<<"birth-month";
		//enter the birth-month
		cin>>m;
		cout<<"birth-year";
		//enter the birth-year
		cin>>y;

			p[q]=Passenger (I,f, l, add,telephone,d,m, y);
	}

		for (int w=0;w<numberofpassenger;w++) //to repeat twice because two passenger info needs to be stored
		{// will print all the information for a passenger
		cout<<"Information for passenger "<<w+1<<endl;
		cout<<"Complete name: "<<p[w].getcompletename1()<<endl
		<<"date of birth: ";p[w].dateofbirth1();cout<<endl;					
		cout<<"ID: "<<p[w].getID1()<<endl
		<<"address: "<<p[w].tel1()<<endl;
		cout<<"phone number: "<<p[w].address1()<<"\n\n";
		}
	return 0;
}



