#include <iostream>
#include <cmath>
using namespace std;

int main()

{
	cout<<"Question 3\n";
	double m1; // makes the variable m1 any number
	double m2; // makes the variable m2 any number
	cout << "Input the first mass in kg, the second mass in kg and the distance in m: \n"; // print out the text
	cin >> m1; // will allow user to input the first mass
	cin >> m2; // will allow user to input the second mass
	double gravitational = 6.673 * pow(10, -11); // setting the type for the constant of gravity and its values
	double distance; // makes the distance any number
	cin >> distance; // will allow user to input any number
	cout <<"The gravitational force is equal to: "<<  gravitational *(m1 * m2) / pow(distance, 2)<<"N"; //calculate the gravity
	return 0; // program successfully ended

} //function is closed



