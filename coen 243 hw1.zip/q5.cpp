#include <iostream>
using namespace std;

int main()

{
	cout<<"Question 5\n";
	double income; //Setting the income as any possible number
	cout<<"Enter you're annual income for the past year:\n "; // will print out the sentence in between the quotations.
	cin>> income; // This will allow the user to input their income
	if (income<45000) // setting an if statement for if the income is lower then 45000$
		cout<<"The tax that the person must pay for an income lower then 45000$ is: " << income*0.06 <<"$\n"; // will print out the text in quotation marks and will use income*0.06 for the tax.
	else if (income>45000 && income<=75000) // Set another statement for an income higher then 45000$ and lower then 75000$
		cout<<"The tax that the person must pay for an income between 45000$ and including 75000$ is: " <<income*0.10 <<"$\n"; // will print the text and use income*0.10 for the tax.
	else if (income>75000) // Set the final statement for an income higher then 75000$
		cout<<"The tax that the person must pay for an income higher than 75000$ is: " <<income*0.12<<"$\n"; // will print out the text and use income*0.12 for the tax.
	return 0; // program was successfully done

} // end of the function



