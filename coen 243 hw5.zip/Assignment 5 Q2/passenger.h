#ifndef PASSENGER_H_
#define PASSENGER_H_
#include<iostream>
#include<string>
using namespace std;
class Passenger{

private:
// initializing variable
	int ID;
	string firstname;
	string lastname;
	string address;
	string tel;
	int day, month, year;
	string completename;

public:
Passenger(int ID, string firstname, string lastname,string tel, string address, int day, int month, int year);
Passenger()=default;
		int getID1();
		string getfirstname1();
		string getlastname1();
		string getcompletename1();
		string tel1();
		string address1();
		void dateofbirth1();

};

#endif /* PASSENGER_H_ */
