#include <iostream>
#include "roman.h"

number::number( string input)
{
    Number1 = input;
}
int number::convert()
                {
                      int length = Number1.length();

                      int p = 0;
                      bool error = false;
                      int n = 0;
                      sum = 0;
                      while( (error == false) && (n < length) )
               {
              switch(Number1[n]) // Apply each case with different n
              {
                  case 'C':
                   sum += 100;
                   if(p < 100)
                   {
                  sum -= 2 * p;
                   }
                   p = 100;
                   break;
                  case 'D':
                   sum += 500;
                   if(p < 500)
                   {
                	   sum -= 2 * p;
                   }
                   p = 500;
                   break;
                 case 'L':
                   sum += 50;
                   if(p < 50)
                   {
                 sum -= 2 * p;
                   }
                   p = 50;
                   break;
                 case 'X':
                   sum += 10;
                   if(p < 10)
                   {
                   sum -= 2 * p;
                   }
                   p = 10;
                   break;
                 case 'V':
                   sum += 5;
                   if(p < 5)
                   {
                 sum -= 2 * p;
                   }
                   p = 5;
                   break;
                 case 'I':
                   sum += 1;
                   if(p < 1)
                   {
                  sum -= 2 * p;
                   }
                   p = 1;
                   break;
                  case 'M':
                   sum += 1000;
                   if(p < 1000)
                   {
                  sum -= 2 * p;
                   }
                   p= 1000;
                   break;
                 }
                    n++;
                      }
                      return sum;
         }






