#include <iostream>
#include <string>
#include <cmath>
#include "date.h"

using namespace std;

// Constructor

Date::Date (int d, int m, int y)

{
 day = d;
 month = m;
 year = y ;
}

// print date

void Date::printDate() const
{
 cout << month << "/" << day << "/" << year << "\n";
}

void Date::monthinletters() // if statement that will print the months in letter depending on the number chosen
{
		if (month==1)
		{
			cout<<"January "<< day << " " << year << "\n";
		}
		if (month==2)
			{
				cout<<"February "<< day << " " << year << "\n";
			}
		if (month==3)
			{
				cout<<"March "<< day << " " << year << "\n";
			}
		if (month==4)
			{
				cout<<"April "<< day << " " << year << "\n";
			}
		if (month==5)
			{
				cout<<"May "<< day << " " << year << "\n";
			}
		if (month==6)
			{
				cout<<"June "<< day << "" << year << "\n";
			}
		if (month==7)
			{
				cout<<"July "<< day << " " << year << "\n";
			}
		if (month==8)
			{
				cout<<"August "<< day << " " << year << "\n";
			}
		if (month==9)
			{
				cout<<"September "<< day << " " << year << "\n";
			}
		if (month==10)
			{
				cout<<"October "<< day << "  " << year << "\n";
			}
		if (month==11)
			{
				cout<<"November "<< day << " " << year << "\n";
			}
		if (month==12)
			{
				cout<<"December "<< day << " " << year << "\n";
			}
}

void Date::date()
{
	int date, month,year;
	cout<<"Enter the year: ";
	cin>> year; // enter the year for the user
	do{ // will enter the month
	cout<<"Enter the month:";
	cin>>month;
	}while(month < 1 || month>12);

	if (month==4||month==6||month==9||month==11) // if the user picks any of these month, they are only allowed to pick a date between 1 and 30 or it will repeat
	{
		do{
			cout<< "Enter the date: ";
			cin>>date;
		}while(date<1 || date>30);
	}

	if (month==1||month==3||month==5||month==7||month==8||month==10||month==12) //if the user picks any of these month, they are only allowed to pick a date between 1 and 31 or it will repeat
	{
		do{
			cout<< "Enter the date: ";
			cin>>date;
		}while(date<1 || date>31);
	}
	if (month==2) //if the user picks month 2, they are only allowed to pick a date between 1 and 28 or it will repeat
		{
			do{
				cout<< "Enter the day (assume february always has 28 days): ";
				cin>>date;
			}while(date<1 || date>28);
		}

Date initialdate1(date,month,year);
// again to it for another date
cout<<"Enter the year for another date: ";
	cin>> year;
	do{
	cout<<"Enter the month:";
	cin>>month;
	}while(month < 1 || month>12);

	if (month==4||month==6||month==9||month==11)
	{
		do{
			cout<< "Enter the date: ";
			cin>>date;
		}while(date<1 || date>30);
	}

	if (month==1||month==3||month==5||month==7||month==8||month==10||month==12)
	{
		do{
			cout<< "Enter the date: ";
			cin>>date;
		}while(date<1 || date>31);
	}
	if (month==2)
		{
			do{
				cout<< "Enter the day (assume febuary always has 28 days): ";
				cin>>date;
			}while(date<1 || date>28);
		}
Date date2(date,month,year);


int x=initialdate1.daysbetweentwodate()-date2.daysbetweentwodate();
if(x<0)
{
	x=x*-1;
}
cout<< "The first date is:";initialdate1.printDate(); //will print the date in number form
cout<< "\nThe second date is:";date2.printDate(); //will print the date in number form
cout<< "\nThe first date in letter:";initialdate1.monthinletters(); //will print in letter
cout<< "\nThe second date in letter:";date2.monthinletters(); //will print in letter
cout<<"\nThe difference between two dates:"<<x<< "days"; //will give the difference in days

}

int main()
{
	Date d(0,0,0);

	d.date();
	return 0;
}
