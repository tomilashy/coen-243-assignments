#ifndef STUDENT_H_
#define STUDENT_H_
#include<iostream>
#include<string>
using namespace std;
class student
{
	public:
	student(int ID,string first,string last,int area,string address, string telephone,int day,int month,int year );
	student();
	int getID();
	string getfirst();
	string getlast();
	int areacode();
	string telephone();
	string address();
	int age();
	void dateofbirth();
	string getfull();


	private:
	int ID; // set as integer
	string first; // set as string
	string last; //set as string
	int area; //set as integer
	int date; //set as integer
	int month; //set as integer
	int year; //set as integer
	int Age; //set as integer
	string Address; //set as string
	string tel; // set as string
	string fullname; //set as string
};

#endif /* STUDENT_H_ */
