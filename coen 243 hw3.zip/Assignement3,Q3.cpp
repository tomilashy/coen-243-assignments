#include <iostream>
#include <array>
#include<algorithm>
#include <iomanip>
using namespace std;

void selectionsort(int x[],int y) // function for sorted
{
	int q,p,w;
	for (p=0; p < y - 1; ++p)
	{

	for ( w= 0 ; w < y - 1; ++w)

		if (x[w] > x[w + 1])
			{
				q = x[w];
				x[w] = x[w + 1];
				x[w + 1] = q;
			}
	}
	cout << "These are the value which where enter from small to big:\n";

	for (int z=0;z<y;z++)
			{
				cout<<setw(3)<<x[z]; // will leave space between each value
				if ((z+1)%10==0)
				cout<<endl;
			}
}

int main()
{
	int y =50;

	int sort[y];

	for (int z=0;z<y;z++)
		{
			cout<<"Enter the numbers "<<z+1<<endl; // will enter all the values
			cin>>sort[z];

		}

	selectionsort(sort,y); // will sort out all the values
}


