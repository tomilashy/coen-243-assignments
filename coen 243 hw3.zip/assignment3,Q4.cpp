#include <iostream>
#include <iomanip>
#include<array>
#include <algorithm>
using namespace std;


const int SIZE = 3;
int numbers[SIZE][SIZE] {{0, 0, 0},{0, 0, 0},{0, 0, 0}}; //setting the size of the matrix 3x3

void fillboard()
{

    int t[9]={1,2,3,4,5,6,7,8,9};
    random_shuffle(&t[1],&t[9]);
       numbers[0][0]=t[0];
       numbers[0][1]=t[1];
       numbers[0][2]=t[2];
       numbers[1][0]=t[3];
       numbers[1][1]=t[4];
       numbers[1][2]=t[5];
       numbers[2][0]=t[6];
       numbers[2][1]=t[7];
       numbers[2][2]=t[8];
       for ( int q= 0; q < SIZE; q++)
       	{
       		for (int w = 0; w < SIZE; w++)
       		{
       				cout<<setw(4)<<numbers[q][w]<<setw(4);

       		}cout<<endl;
       	}cout<<endl<<endl;

}

void showboard() // will print out the array that is a magic square
{
	for (int q = 0; q < SIZE; q++)
	{
		for (int w = 0; w < SIZE; w++)
		{
			cout << numbers[q][w] << " ";
		}
		cout << endl;
	}
}
bool ismagic() // a function that will solve if the array is magic or not
{
	int a = numbers[0][0] + numbers[0][1] + numbers[0][2]; // initializing a
	for (int q = 1; q < SIZE; q++)
	{
		if (numbers[q][0] + numbers[q][1] + numbers[q][2] != a) // if this statement is true return false
			return false;
	}
	for (int q = 0; q < SIZE; q++)
	{
		if (numbers[0][q] + numbers[1][q] + numbers[2][q] != a) // if this statement is true return false
			return false;
	}
	if (numbers[0][0] + numbers[1][1] + numbers[2][2] != a) // if this statement is true return false
		return false;


	if (numbers[0][2] + numbers[1][1] + numbers[2][0] != a) // if this statement is true return false
		return false;

	return true;
}
void additionofnumber() // function that will add the number of the array
{int allnumber=0;
	for (int q = 0; q < SIZE; q++)
	{
		for (int w = 0; w < SIZE; w++)
		{

			allnumber +=numbers[q][w];
		}
	}
	cout<<"The addition of the number in the array divided by 3 = "<<allnumber/3;
}
int main()
{
	cout<<"Enter the amount of attempt required: ";
	int counter,p;
	cin>>p;
		for (counter=p;counter>0;counter--)
		{
			do
				{
			cout << counter <<")." <<endl;
			fillboard();
			break;
				} while (!ismagic());
		}
	showboard();
	additionofnumber();

	return 0;
}

