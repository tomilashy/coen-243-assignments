#include <iostream>
#include <cmath>
using namespace std;


int main() {
	int x,y,z; // Initializing the variables as integer
	cout<<"Enter the values for the first dish: ";
	cin>> x; // the time for the first dish
	cout<<"Enter the time difference between dishes: ";
	cin>> y; //time difference between each dish
	cout<<"Enter the values for total time the person has: ";
	cin>> z; // total time in hand
	int a,b,c,d; // initializing the variable for the quadratic formula
	int r1,r2;
	a=y;
	b=(2*x-y);
	c=-2*z;
	d=pow(b,2)-4*a*c;
	r1=(-b-sqrt(d))/(2*a); // one of the answer of the quadratic equation
	r2=(-b+sqrt(d))/(2*a); // one of the answer of the quadratic equation
	if(r1>0) // if statement if r1 is greater then 0 then print next line
		cout<<"The maximum of dishes is "<<r1;
	if(r2>0) // if statement if r2 is grater then 0 then print next line
		cout<<"The maximum of dishes is "<<r2;
return 0;
}




