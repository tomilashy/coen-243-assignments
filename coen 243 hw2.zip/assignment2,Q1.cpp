#include <iostream>
#include <iomanip>
#include<cmath>
using namespace std;


long double factorial(int x){
	if (x==0) // if statement for saying that when x is equal to 0 then return 1
		return 1;
		else
			return x*factorial(x-1); // if the if statement is false then print this equation
}
int main()
{ int n,i; // Initializing n and i to be an integer
long double e=0;
cout<<"Enter a value for n: "; // print the text
cin>>n; // input the number
for(i=0; i<=n;i++) // for loop where i starts at 0 and keep on increasing until i is smaller or equal to n
{
	e += (factorial(n))/(factorial((n-i))*factorial(i)*pow(n,i)); // e is equal to e plus the equation
}
cout<<"The value of e is equal to "<<setprecision(17)<<e; // print the of e and to precision of 17 decimal point


}


